export const products = [
    {
        image: '/images/products/product1.png',
        title: 'ASPARAGUS GREEN FRESH',
        skuCode: '000 102',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product2.png',
        title: 'BAMBOO SHOOT FRESH',
        skuCode: '000 103',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product3.png',
        title: 'BASIL FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product4.png',
        title: 'BEAN SPROUT FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product5.png',
        title: 'BEAN SPROUT LARGE (SOYA) FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product6.png',
        title: 'BROCCOLI FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },

    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },

    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    }, {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },

    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },

    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    }, {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },

    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    }, {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    },
    {
        image: '/images/products/product1.png',
        title: 'BEETROOT TOPPED FRESH',
        skuCode: '000 101',
        labels: ['Provisions', 'Fresh Vegetables']
    }
]